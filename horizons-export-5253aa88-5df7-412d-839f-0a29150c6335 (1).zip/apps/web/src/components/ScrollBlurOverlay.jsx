import React from 'react';
import { useScrollBlur } from '../hooks/useScrollBlur.js';

export default function ScrollBlurOverlay() {
  // Fade in over 400px, hold until 800px, fade out completely by 1200px
  const blur = useScrollBlur(12, 400, 800, 1200);

  if (blur === 0) return null;

  return (
    <div 
      className="fixed top-0 left-0 right-0 h-[30vh] pointer-events-none z-30"
      style={{ 
        backdropFilter: `blur(${blur}px)`,
        WebkitBackdropFilter: `blur(${blur}px)`,
        backgroundColor: `rgba(255, 255, 255, ${blur / 80})`,
        // Use a gradient mask so the blur smoothly transitions to clear at the bottom of the 30vh area
        maskImage: 'linear-gradient(to bottom, rgba(0,0,0,1) 20%, rgba(0,0,0,0) 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, rgba(0,0,0,1) 20%, rgba(0,0,0,0) 100%)',
        transition: 'backdrop-filter 0.1s ease-out, background-color 0.1s ease-out'
      }}
    />
  );
}