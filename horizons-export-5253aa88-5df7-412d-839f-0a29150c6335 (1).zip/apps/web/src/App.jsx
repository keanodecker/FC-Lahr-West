import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/sonner';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import HomePage from './pages/HomePage.jsx';
import AboutPage from './pages/AboutPage.jsx';
import TeamsPage from './pages/TeamsPage.jsx';
import NextMatchPage from './pages/NextMatchPage.jsx';
import StatisticsPage from './pages/StatisticsPage.jsx';
import ScrollBlurOverlay from './components/ScrollBlurOverlay.jsx';
import ParticleSystem from './components/ParticleSystem.jsx';

function App() {
  return (
    <Router>
      <Helmet>
        <title>FC Lahr-West 1975 e.V. - Leidenschaft. Teamgeist. Heimat.</title>
        <meta 
          name="description" 
          content="FC Lahr-West 1975 e.V. - Fußballverein in Lahr/Schwarzwald. Mitglied im Südbadischen Fußballverband. Zwei Mannschaften, eine Leidenschaft." 
        />
      </Helmet>

      <div className="min-h-screen flex flex-col relative">
        <ParticleSystem />
        <ScrollBlurOverlay />
        <Header />
        
        <main className="flex-grow relative z-10">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/teams" element={<TeamsPage />} />
            <Route path="/next-match" element={<NextMatchPage />} />
            <Route path="/statistics" element={<StatisticsPage />} />
            <Route path="*" element={<HomePage />} />
          </Routes>
        </main>
        
        <Footer />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;