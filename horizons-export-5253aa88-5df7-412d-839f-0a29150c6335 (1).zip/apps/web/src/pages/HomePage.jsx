import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import HeroSection from '../components/HeroSection.jsx';
import AboutSection from '../components/AboutSection.jsx';
import TeamsSection from '../components/TeamsSection.jsx';
import NextMatchSection from '../components/NextMatchSection.jsx';
import StatisticsSection from '../components/StatisticsSection.jsx';
import ContactSection from '../components/ContactSection.jsx';

export default function HomePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const element = document.querySelector(location.hash);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />
      <AboutSection />
      <TeamsSection />
      <NextMatchSection />
      <StatisticsSection />
      <ContactSection />
    </div>
  );
}