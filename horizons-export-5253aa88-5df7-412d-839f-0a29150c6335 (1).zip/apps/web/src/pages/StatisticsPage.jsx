import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import StatisticsSection from '../components/StatisticsSection.jsx';

export default function StatisticsPage() {
  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="pt-20 min-h-screen bg-background"
    >
      <Helmet>
        <title>Statistik | FC Lahr-West 1975 e.V.</title>
        <meta name="description" content="Zahlen, Daten und Fakten rund um den FC Lahr-West 1975 e.V." />
      </Helmet>
      
      <div className="bg-muted py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Zahlen & Fakten</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Ein Blick auf die beeindruckenden Statistiken unseres Vereins seit der Gründung im Jahr 1975.
          </p>
        </div>
      </div>

      <StatisticsSection />
    </motion.div>
  );
}