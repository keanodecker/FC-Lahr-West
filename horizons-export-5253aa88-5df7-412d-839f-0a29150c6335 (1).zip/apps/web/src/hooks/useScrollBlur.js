import { useState, useEffect } from 'react';

export function useScrollBlur(maxBlur = 12, fadeInEnd = 400, fadeOutStart = 800, fadeOutEnd = 1200) {
  const [blur, setBlur] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      let currentBlur = 0;

      if (y <= fadeInEnd) {
        // Progressively increase blur as user scrolls down initially
        currentBlur = (y / fadeInEnd) * maxBlur;
      } else if (y <= fadeOutStart) {
        // Hold max blur for a specific scroll distance
        currentBlur = maxBlur;
      } else if (y <= fadeOutEnd) {
        // Progressively fade out the blur as user scrolls past the initial sections
        const progress = (y - fadeOutStart) / (fadeOutEnd - fadeOutStart);
        currentBlur = maxBlur * (1 - progress);
      } else {
        // Completely remove blur for lower content
        currentBlur = 0;
      }

      setBlur(Math.max(0, currentBlur));
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Init on mount

    return () => window.removeEventListener('scroll', handleScroll);
  }, [maxBlur, fadeInEnd, fadeOutStart, fadeOutEnd]);

  return blur;
}